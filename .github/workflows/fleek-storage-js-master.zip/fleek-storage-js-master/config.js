const config = {
  ipfsGateway: 'https://ipfs.fleek.co/ipfs',
  storageEndpoint: 'https://storageapi.fleek.co',
  fleekGraphQl: 'https://h6qbvxquqjg5direndhm7ugaj4.appsync-api.us-west-2.amazonaws.com/graphql'
};

module.exports = config;
